# -*- coding: utf-8 -*-
"""
Created on Fri Apr  3 23:01:51 2020
@author: adria
"""
import pandas as pd
from pre_proc import pre_proc_clean,pre_proc_clean2
import nltk
from nltk import bigrams as bg
from nltk.corpus import stopwords
import itertools
import collections



# Create list of lists containing bigrams in tweets
terms_bigram = [list(bg(tweet)) for tweet in pre_proc_clean2()]
# View bigrams for the first tweet
terms_bigram[0]
[('virus', 'outlook'),
 ('outlook', 'fond'),
 ('fond', 'hope'),
 ('hope', 'alarmists'),
 ('alarmists', 'want'),
 ('want', 'get'),
 ('get', 'everyone'),
 ('everyone', 'travellin…')]

# Original tweet without URLs
#tweets_no_urls[0]
#'What does the virus do for the outlook and fond hope of climate change alarmists who want to get everyone travellin
# Clean tweet 
#tweets_nsw_nc[0]
'''
['virus',
 'outlook',
 'fond',
 'hope',
 'alarmists',
 'want',
 'get',
 'everyone',
 'travellin…']
'''
bigrams = list(itertools.chain(*terms_bigram))
# Create counter of words in clean bigrams
bigram_counts = collections.Counter(bigrams)
bigram_counts.most_common(30)
bigram_df = pd.DataFrame(bigram_counts.most_common(30),columns=['bigram', 'count'])

def bigrams_show():
  print(bigram_df)




