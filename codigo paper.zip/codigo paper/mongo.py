# -*- coding: utf-8 -*-
"""
Created on Fri Apr  3 17:51:07 2020
@author: adria
This module can connecto to a mongo cluster 
"""
from pymongo import MongoClient
client = MongoClient()
db = client['twitter_db']
collection = db['twitter_collection']

def conn_mongodb():
 client = MongoClient()
 db = client['twitter_db']
 collection = db['twitter_collection']

