# -*- coding: utf-8 -*-
"""
Created on Fri Apr  3 17:36:59 2020
This module corresponds to Twitter connection and authentication
@author: adria
"""
import tweepy as tw
from pymongo import MongoClient

def authentication():
    # Consumer keys and access tokens, used for OAuth
    consumer_key = 'lH0yfv6P7S3rs9AqKwp7NjWI9'
    consumer_secret = 'wU7ZLTpcQZuvuIT7dTcXMmalGHDL2PvR73HpXqTvuNErobAn8w'
    access_token = '1091142656938389504-MHBr9MK7GPLj1rPB8JHRKTuHODFOW6'
    access_token_secret = 'Z8N3jJVo2fT4DcQRV7yZpKG70OhtX2XvM8tRjikVIPLK6'
     
    # OAuth process, using the keys and tokens
    auth = tw.OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_token_secret)
    # Creation of the actual interface, using authentication
    return auth

api = tw.API(authentication(),wait_on_rate_limit=True)


