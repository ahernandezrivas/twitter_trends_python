# -*- coding: utf-8 -*-
"""
Created on Fri Apr  3 17:36:59 2020
This module corresponds to Twitter connection and authentication
@author: adria
"""
import tweepy as tw
from pymongo import MongoClient

def authentication():
    # Consumer keys and access tokens, used for OAuth
    consumer_key = 'your key'
    consumer_secret = 'your secret'
    access_token = 'acces token'
    access_token_secret = 'acces token secret'
     
    # OAuth process, using the keys and tokens
    auth = tw.OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_token_secret)
    # Creation of the actual interface, using authentication
    return auth

api = tw.API(authentication(),wait_on_rate_limit=True)


