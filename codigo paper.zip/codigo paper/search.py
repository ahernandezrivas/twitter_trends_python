# -*- coding: utf-8 -*-
"""
Created on Fri Apr  3 17:58:59 2020
@author: adria
"""
import tweepy 
from auth import authentication
from auth import api
from pymongo import MongoClient
from mongo import conn_mongodb
from mongo import collection

conn_mongodb()

def seek_twitter_term(text_to_search,no_items):
 for data in tweepy.Cursor(api.search,q=text_to_search, lang="es").items(no_items):
  collection.insert(data._json)        
  #z.append(data)
  #print(z) 

def retrieve_unformated_tweets():
  print('Total Record for the collection: ' + str(collection.count()))
  for record in collection.find().limit(10):    
   print(record) 
   
   
   
   
