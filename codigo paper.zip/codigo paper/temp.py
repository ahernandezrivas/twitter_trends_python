# -*- coding: utf-8 -*-
"""
Created on Fri Apr  3 17:53:54 2020

@author: adria
"""

# -*- coding: utf-8 -*-
"""
Created on Sun Mar  3 20:20:17 2019

@author: adria"""

from networkx.readwrite import json_graph
import dns
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import itertools
import collections


import nltk
from nltk import bigrams
from nltk.corpus import stopwords
import re
import networkx as nx
import warnings
warnings.filterwarnings("ignore")

sns.set(font_scale=1.5)
sns.set_style("whitegrid")

import simplejson as json

import argparse
import configparser
import datetime

import login
from mongo import collection
from search import lookup_term

se = "Coronavirus"

     

lookup_term(se)



#currentDT = datetime.datetime.now()
#concatenar="'"
#nombre_bd="twitter"+str(currentDT)
#print(nombre_bd)



'''
silo={}
lista__bd=[]
lista_bd=db.list_collection_names()
lista_c=[]
lista_d=[]
i=0
for i in range (len(lista_bd)):
 collection = db[lista_bd[i]]  
 for record in collection.find():
   lista_d.append(record)
   lista_c.append(list(lista_d))
  
   
silo=lista_c
print(silo)
'''
'''
listoflists = []
a_list = []
for i in range(0,10):
    a_list.append(i)
    if len(a_list)>3:
        a_list.remove(a_list[0])
        listoflists.append((list(a_list), a_list[0]))
print (listoflists)
'''


#print(db.list_collection_names())
# Creacion de la busqueda personalizada

############################################################################

#print(x)
#z=x[1:len(lista_bd[0])-1]
#print(x)


     
      # dic.append(record)
 

#alltweetscol = []
#alltweetscol.extend(tweets)
#client = MongoClient()
#or


#for data in tweepy.Cursor(api.search,q=search_term,lang="es",since="2020-03-28").items(10): 
 #   z.append(data)
    
    #with open('file._json', 'w') as file:
     #file.write(json.dumps(data._json))
  #  print(z)                     
         
#dic=z
#print(dic)


#app_json = json.dumps(dic)
#print(dic)




'''
dic = []
print('Total Record for the collection: ' + str(collection.count()))
for record in collection.find().limit(4000):
       print(record) 
       dic.append(record)
      # collection.find({'text' : 'This will return tweets with only this exact string.'}) 
