from search import seek_twitter_term
from search import retrieve_unformated_tweets
from pre_proc import pre_proc_clean
from bigrams_from_tweets import bigrams_show
from plots import plot_terms_frequency,plot_nx_network
       







'''

searchtxt="lopezobrador"
num_items=500
seek_twitter_term(searchtxt,num_items)

'''

pre_proc_clean()
bigrams_show()
plot_terms_frequency()
plot_nx_network()
       


