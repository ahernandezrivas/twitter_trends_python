# -*- coding: utf-8 -*-
"""
Created on Fri Apr  3 23:01:10 2020

@author: adria
"""
from clean import remove_url
from pymongo import MongoClient
from mongo import conn_mongodb
from mongo import collection
import nltk
from nltk import bigrams
from nltk.corpus import stopwords
import collections

def pre_proc_clean():
    tweets_iterator = collection.find()
    # Remove URLs
    tweets_no_urls = [remove_url(tweet['text']) for tweet in tweets_iterator]    
    # Create a sublist of lower case words for each tweet
    words_in_tweet = [tweet.lower().split() for tweet in tweets_no_urls]    
    return words_in_tweet

def pre_proc_clean2():    
    # Download stopwords
    nltk.download('stopwords')
    stop_words = set(stopwords.words('spanish'))
    
    # Remove stop words from each tweet list of words
    tweets_nsw = [[word for word in tweet_words if not word in stop_words]
                  for tweet_words in pre_proc_clean()]    
    # Remove collection words
    collection_words = ['coronavirus', 'cuarentena', 'cambio']    
    tweets_nsw_nc = [[w for w in word if not w in collection_words]
                     for word in tweets_nsw]
    ##[nltk_data] Downloading package stopwords to /root/nltk_data...
    ##[nltk_data]   Package stopwords is already up-to-date!
    return tweets_nsw_nc
