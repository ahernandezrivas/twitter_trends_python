# -*- coding: utf-8 -*-
"""
Created on Sat Apr  4 00:04:10 2020

@author: adria
"""
from bigrams_from_tweets import bigram_counts
from bigrams_from_tweets import bigram_df
import matplotlib.pyplot as plt
import networkx as nx
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")
sns.set(font_scale=1.5)
sns.set_style("whitegrid")

def plot_terms_frequency():
    y = [count for tag, count in bigram_counts.most_common(100)]
    x = range(1, len(y)+1)
    #Crear Grafica de Frecuencia de Terminos
    plt.bar(x, y)
    plt.title("Frecuencia de Terminos")
    plt.ylabel("Frequencuencia")
    plt.savefig('term_distribution.png')


def plot_nx_network():
# Create dictionary of bigrams and their counts
    d = bigram_df.set_index('bigram').T.to_dict('records')   
      # Create network plot 
    # Create network plot 
    G = nx.Graph()
    
    # Create connections between nodes
    for k, v in d[0].items():
        G.add_edge(k[0], k[1], weight=(v * 10))
    
    G.add_node("china", weight=100)
    fig, ax = plt.subplots(figsize=(10,8))
    
    pos = nx.spring_layout(G, k=2)
    
    # Plot networks
    nx.draw_networkx(G, pos,
                     font_size=16,
                     width=1,
                     edge_color='black',
                     node_color='yellow',
                     with_labels = False,
                     ax=ax)
    
    # Create offset labels
    for key, value in pos.items():
        x, y = value[0], value[1]
        ax.text(x, y,
                s=key,
                bbox=dict(facecolor='yellow', alpha=0.25),
                horizontalalignment='center', fontsize=13)
        
    plt.show()
       

       